🧩 README.txt
Projet : Tiers-lieux vs. Monsieur Tentacules
Auteur : Marcos Medina-Tabares
Université de Lorraine – Laboratoire ERPI / ENSGSI – Master 2 IUVTT
Année : 2025

------------------------------------------------------------
🎯 Objectif du jeu
------------------------------------------------------------
Tiers-lieux vs. Monsieur Tentacules est un jeu sérieux conçu dans le cadre d’une
recherche sur le management inclusif des tiers-lieux. Il vise à favoriser la
réflexion collective, la coopération et la créativité des équipes de tiers-lieux,
en s’appuyant sur les valeurs de diversité, inclusion et solidarité.

Le jeu permet aux participants de se confronter à des défis inspirés de situations
réelles et de trouver ensemble des solutions adaptées à leur territoire.

------------------------------------------------------------
🧱 Contenu du dossier ZIP
------------------------------------------------------------
/Cartes/                 → Ensemble des cartes du jeu (PDF ou images imprimables)
/Puzzle-Maison/          → Fichiers pour le puzzle et la boîte (format DXF)
/README.txt              → Ce fichier d’information

------------------------------------------------------------
⚖️ Licences et droits d’auteur
------------------------------------------------------------

🟣 Cartes du jeu
Création originale © 2025 Marcos Medina-Tabares
Diffusée sous licence Creative Commons BY-NC-SA 4.0 International
https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode.fr

Vous pouvez partager et adapter le jeu à condition :
- de citer l’auteur,
- de ne pas l’utiliser à des fins commerciales,
- et de partager vos versions sous la même licence.

🔵 Puzzle et boîte
© 2025 Florian Festi — sous licence GNU GPLv3
https://www.gnu.org/licenses/gpl-3.0.html

Ces fichiers peuvent être modifiés et redistribués librement,
à condition de conserver la même licence et les mentions d’origine.

------------------------------------------------------------
🧠 Origine scientifique du projet
------------------------------------------------------------
Cette recherche a été réalisée par Marcos Medina-Tabares dans le cadre d’un stage
de recherche au Laboratoire ERPI (Université de Lorraine), sous la supervision de
Manon Enjolras, Ferney Osorio et Laurent Rollet.

Le projet s’inscrit dans le Master 2 Urbanisme et Aménagement – parcours Innovation
Urbaine pour des Villes et Territoires en Transition (ENSGSI).

💰 Financement
L'auteur remercie le programme ORION pour sa contribution au financement
du stage de recherche de M. Medina-Tabares.
Ce travail a bénéficié d'une aide de l’État gérée par l’Agence Nationale de la
Recherche au titre du Programme d’Investissements d’Avenir portant la référence ANR-20-SFRI-0009.

------------------------------------------------------------
🕹️ Comment utiliser le jeu
------------------------------------------------------------
1. Imprimez les cartes et le matériel de jeu.
2. Assemblez le puzzle et la boîte si vous disposez d’un découpeur laser (.DXF fournis).
3. Organisez une session de jeu (3 à 6 participants) avec un facilitateur.
4. Lisez le Mode d’emploi pour connaître le déroulé et les règles.
5. Jouez, échangez et analysez les freins et leviers de votre pratique de gestion collective.

------------------------------------------------------------
🌐 Ressources complémentaires
------------------------------------------------------------
Site web du projet :
https://mmedinata.github.io/Tiers-lieux-vs.-Monsieur-Tentacules/

------------------------------------------------------------
📬 Contact
------------------------------------------------------------
Auteur : Marcos Medina-Tabares
LinkedIn : https://www.linkedin.com/in/mmedinata/
Laboratoire ERPI – Université de Lorraine
Nancy, France

