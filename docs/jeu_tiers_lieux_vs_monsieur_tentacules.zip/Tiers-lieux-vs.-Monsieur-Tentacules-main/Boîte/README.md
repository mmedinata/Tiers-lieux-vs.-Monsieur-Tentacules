# Boîte du montage

Ces fichiers représentent la boîte de montage utilisée dans le jeu.  
Ils sont la création de **Florian Festi**, diffusé dans son site https://boxes.hackerspace-bamberg.de/ .

## Licence
© Copyright 2025, Florian Festi  
Distribué sous **GNU General Public License v3.0 (GPLv3)**.  
→ [Texte complet](https://www.gnu.org/licenses/gpl-3.0.html)
